#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Aug  5 14:11:37 2020

@author: waelfatnassi
"""

import PolyAR
import numpy as np
import polytope as pc
import timeit


from z3 import *

import time



#***************************************************************************************************
#***************************************************************************************************
#
#         CLASS SMPolyIneqSolver
#
#***************************************************************************************************
#***************************************************************************************************

class SMPolyIneqSolver:
    
    # ========================================================
    #       Constructor
    # ========================================================
    def __init__(self, numOfBoolVars, numOfRealVars, numOfPolyIFClauses, pregion,
             maxNumberOfIterations = 1000, counterExampleStrategy = 'Trivial', verbose = 'OFF', profiling = 'true'):
        
        # ------------ Initialize SAT Solvers   ---------------------------------------
        self.SATsolver                  = z3.Solver()
        self.SATsolver.reset()
        
        # ------------ Initialize Public Variables ------------------------------------
        self.numOfBoolVars=numOfBoolVars
        self.numOfRealVars=numOfRealVars
        self.numOfPolyIFClauses=numOfPolyIFClauses
        self.bVars                      = z3.BoolVector('b', numOfBoolVars)
        self.polyIFClauses              = z3.BoolVector('bPoly', numOfPolyIFClauses) # Boolean abstraction of PolyIFClauses
        self.pregion = pregion
        self.poly_inequality_coeffs  = []
        
        self.counterExamples            = list()
        
        self.ambiguous_regions_polys={}  # ambiguous regions of all polys in poly_inequality_coeffs
        self.negative_regions_polys={}  # negative regions of all polys in poly_inequality_coeffs
        self.positive_regions_polys={} # positive regions of all polys in poly_inequality_coeffs
        
        
        
        # ------------ Initialize Solver Parameters ------------------------------------
        self.maxNumberOfIterations      = maxNumberOfIterations
        self.counterExampleStrategy     = counterExampleStrategy
        self.verbose                    = verbose
        self.profiling                  = profiling




    # ========================================================
    #               Add Boolean Constraints
    # ========================================================
    def addBoolConstraint(self, constraint):
        self.SATsolver.add(constraint)
        
    # ========================================================
    #               Add Poly Constraints
    # ========================================================
    def addPolyConstraint(self, poly):
        self.poly_inequality_coeffs.append(poly)

        
        
        
        
    # ========================================================
    #               Main Solver Function
    # ========================================================
    def solve(self):
        
        
        solutionFound                       = False
        iterationsCounter                   = 0
        # ------------ Main Loop ------------------------------------------------------
        while solutionFound == False and iterationsCounter < self.maxNumberOfIterations:
            iterationsCounter               = iterationsCounter + 1



            if self.profiling == 'true':
                start = timeit.default_timer()
            SATcheck                        = self.SATsolver.check()
            if self.profiling == 'true':
                end = timeit.default_timer()
                print('SAT time', end-start)
        # ------------ Call SAT solver -------------------------------------------------
            if  SATcheck == z3.unsat:
                print ('========== ERROR: Problem is UNSAT ==========')
                return list(), list(), list()
            else:
        # ------------ Extract Boolean Models ------------------------------------------
                polyIFModel, bModel         = self.extractSATModel()
                # for i in range(len(polyIFModel)):
                #     if polyIFModel[i]==False:
                #         polyIFModel[i]=1.5
                # print(bModel)
                # print('###########################')
                # print(polyIFModel)
                # break
                #print 'ConvIfModel = ', [i for i, x in enumerate(convIFModel) if x == True]

        # ------------ Solve convex problem --------------------------------------------
                if self.profiling == 'true':
                    start                       = timeit.default_timer()
                

                self.Getregions(polyIFModel)
                # break

                
                polySolnFound, xsol               = self.solvePolyIneqsProblem(polyIFModel)
                if self.profiling == 'true':
                    end                         = timeit.default_timer()
                    print('solve conv problem', end - start)
                
                #print('stat ', convStatus, constrainedConvSolver.solution.get_status_string())
                    
                # if polySolnFound == 'UNSAT':
                #     print ('========== ERROR: Problem is INFEASIBLE ==========')
                #     return list(), list(), list()
                            
                if polySolnFound == 'SAT' :
                    return xsol, bModel
                else:

        # ------------ Find counterexample----------------------------------------------
                    if self.profiling == 'true':
                        start = timeit.default_timer()
                    for i in range(len(polyIFModel)):
                        if polyIFModel[i]==1.5:
                            polyIFModel[i]=False    
                    counterExamples         = self.generateCounterExample(polyIFModel)
                    if not counterExamples: # no counter example can be found .. something is wrong
                        print ('========== ERROR: Problem is UNSAT ==========')
                        return list(), list(), list()
                    if self.profiling == 'true':
                        end = timeit.default_timer()
                        print('gen counterexample', end - start)
        # ------------ Add counter examples to SAT solver --------------------------------
                    for counterExample in counterExamples:
                        self.SATsolver.add(counterExample)
        # ------------ END OF MAIN LOOP -------------------------------------------------

        return list(), list(), list()
    
    
    # ========================================================
    #               Extract SAT Model
    # ========================================================
    def extractSATModel(self):
        z3Model                 = self.SATsolver.model()
        convIFModel             = [z3.is_true(z3Model[bConv])   for bConv   in self.polyIFClauses]
        bModel                  = [z3.is_true(z3Model[b])       for b       in self.bVars]
        return convIFModel, bModel
    
    
    
    
    
    # ========================================================
    #               Generate Trivial Counterexample
    # ========================================================
    def generateCounterExample(self,polyIFModel):
        counterExamples                         = list()
        if self.verbose == 'ON':
            print ('********* Generating Counterexample *********')
            
        if self.counterExampleStrategy == 'Trivial':
            # trivial counterexample: extract all constraints that are assigned to true
            activeIFClauses         = [i for i, x in enumerate(polyIFModel) if x != True]

            counterExample              = z3.Or([ self.polyIFClauses[counter] != polyIFModel[counter] for counter in activeIFClauses ])
            self.counterExamples.append(activeIFClauses)
            counterExamples.append(counterExample)
       
        return counterExamples
    
    
    
    # ========================================================
    #               Solve Poly Inequalities Problem
    # ========================================================
    def solvePolyIneqsProblem(self, polyIFModel):
        
        # Extract the acive constraints that are assigned to True 
        activeIFClauses               = [i for i, x in enumerate(polyIFModel) if x == True]
        
        # Extract the inacive constraints that are assigned to False 
        inactiveIFClauses               = [i for i, x in enumerate(polyIFModel) if x == False]
        

        

        
        solver = PolyAR.PolyInequalitySolver(self.numOfRealVars, self.pregion)
        solver.poly_inequality_coeffs=[self.poly_inequality_coeffs[i] for i in activeIFClauses]
        solver.ambiguous_regions_polysss=[self.ambiguous_regions_polys[i] for i in activeIFClauses]
        
        sign_regions_polysss=[]
        type_regions=[]
         
        for i in range(self.numOfPolyIFClauses):
            
            if i in activeIFClauses:    
                sign_regions_polysss.append(self.negative_regions_polys[i])
                type_regions.append('N')
            
            else:
                sign_regions_polysss.append(self.positive_regions_polys[i])
                type_regions.append('P')

        
        solver.sign_regions_polysss=sign_regions_polysss
        solver.type_regions=type_regions
        res=solver.solve()
        
        return res
    
            
            
    # ========================================================
    # Get ambigous, negative or positive regions(depends on a)
    #        of polynomial constraints 
    # ========================================================
    def Getregions(self,polyIFModel):
        
        # Extract the acive constraints that are assigned to True 
        activeIFClauses               = [i for i, x in enumerate(polyIFModel) if x == True]

        
        # Extract the inacive constraints that are assigned to False 
        inactiveIFClauses               = [i for i, x in enumerate(polyIFModel) if x == False]
        
        
        # print('ambiguous_regions',self.ambiguous_regions_polys)
        
        if len(self.ambiguous_regions_polys)!=0:
            neg_keys=list(self.negative_regions_polys.keys())
            pos_keys=list(self.positive_regions_polys.keys())
            
        # Obtain the difference of (neg_keys and activeIFClauses) (pos_keys and inactiveIFClauses)  
            activeIFClauses=self.Diff(activeIFClauses, neg_keys)
            inactiveIFClauses=self.Diff(inactiveIFClauses, pos_keys)
            
    
    
        # Call the nonlinear solver to partition to ambiguous, positive (inactive clause), and negative (inactive clause)
        solver = PolyAR.PolyInequalitySolver(self.numOfRealVars, self.pregion)
        solver.poly_inequality_coeffs=self.poly_inequality_coeffs
        
        for poly_index in range(self.numOfPolyIFClauses):
            
            x0_min=-100.0 
            x0_max =100.0                    
            box=np.array(self.hypercube(self.numOfRealVars, x0_min,x0_max))
            polype=pc.box2poly(box)
            pregion=[[{'A':polype.A,'b':polype.b}]]
            
            if poly_index in activeIFClauses:
                
                ambiguous_regions,negative_regions=solver.iterat(pregion,poly_index,'N')
                self.ambiguous_regions_polys.update({poly_index:ambiguous_regions})
                self.negative_regions_polys.update({poly_index:negative_regions})
                
            else:    
                
                ambiguous_regions,positive_regions=solver.iterat(pregion,poly_index,'P')
                self.ambiguous_regions_polys.update({poly_index:ambiguous_regions})
                self.positive_regions_polys.update({poly_index:positive_regions})


  

    # ========================================================
    #   Output s string in this form:'x0 x1...xn'
    # ========================================================
    
    def strVari(self,n):
        variables=''
        for i in range(0,n):
            variables=variables+'x'+str(i)+' '
        c= variables[:-1]  
        return c    
    
    # ========================================================
    #   Obtain the list of elements of list1 that does not 
    #             belong to list2
    # ========================================================

    def Diff(self,list1, list2): 
        return (list(list(set(list1)-set(list2))))


    # ========================================================
    #   Function to output the n^th dimenstion hypercube
    #      with edge limited between xmin and xmax
    # ========================================================
    def hypercube(self,n,xmin,xmax):
        box=[]
        for i in range(n):
            box.append([xmin,xmax])
        
        return box         
            
    # ========================================================
    # Use Z3 to Solve the SMP (boolean+polynomial constraints)
    # ========================================================
     
    def Z3_SMP(self,clauses):
        solver = z3.Solver()
        x = z3.Reals(self.strVari(self.numOfRealVars))
        bVars =self.bVars 
        
        ccc=(self.pregion[0][0]['A'])*x
        cc=np.sum(ccc,axis=1)
        c=cc-self.pregion[0][0]['b'] 
   
        for i in range(len(c)):
            solver.add(c[i]<=0)
        
        polycs=[]
        polys=self.poly_inequality_coeffs
        for poly in polys:
            poly_constraint = 0
            for monomial_counter in range(0,len(poly)):
                coeff = poly[monomial_counter]['coeff']
                vars  = poly[monomial_counter]['vars']
                product = coeff
    
                for var_counter in range(len(vars)):
                    power = vars[var_counter]['power']
                    var   = x[var_counter]  
                    product = product * (var**power)
                poly_constraint = poly_constraint + product
            polycs.append(poly_constraint)
            
            
        for clause in clauses:
            
            if clause[0]=='b':
                solver.add(clause[1])
            elif clause[0]=='p':
                polycsx=[polycs[i] for i in clause[2]]
                solver.add(z3.Implies(self.bVars[clause[1]],z3.And(polycsx[0]<0,polycsx[1]<0)))

                    
        if solver.check() == sat:
            model = solver.model()
            return model


        return None          
        

        
        
    
    
    
    
    
#=========================================================
#       Public Helper APIs
#=========================================================

# ============ Helper Functions to construct Boolean clauses ======================
def AND(*b):
    return z3.And(b)

def OR(*b):
    return z3.Or(b)

def NOT(b):
    return z3.Not(b)

def IMPLIES(b1, b2):
    return z3.Implies(b1, b2)

def EQUIV(b1, b2):
    return b1 == b2
    #return AND(IMPLIES(b1, b2), IMPLIES(b2, b1))

# ============ Helper Functions to construct pseudo Boolean clauses ===============
def BoolVar2Int(b):
    return  z3.If(b, 1, 0)









    
        
        