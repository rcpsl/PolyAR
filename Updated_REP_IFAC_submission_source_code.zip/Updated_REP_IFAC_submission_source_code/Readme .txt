﻿PolyAR: A Highly Parallelizable Solver For Polynomial Inequality Constraints Using Convex Abstraction Refinement

1. Introduction
-----------------
This Python package contains the implementation of the algorithms described
in the paper "PolyAR: A Highly Parallelizable Solver For Polynomial Inequality Constraints Using Convex Abstraction Refinement", Wael Fatnassi, Yasser Shoukry, IFAC 2021. This file describes the contents of the package, and provides instructions regarding its use. This package is used to generate a table and two figures documented in Section 6 (entitled Numerical Results) in the paper, i.e., Table 1, Figure 4, and Figure 5.

2. Installation
-----------------
The tool was written for Python 3.7.6. Earlier versions may be sufficient, but not tested. In addition to Python 3.7.6, the solver requires the following:

- Z3 4.8.9 solver: pip install z3-solver
- Yices 2.6.2 solver: Please follow the instruction at this URL (https://yices.csl.sri.com) 
- scipy: pip install scipy
- autograd: pip install autograd 
- numpy: pip install numpy
- polytope: pip install polytope
- sympy: pip install sympy
- matplotlib: pip install matplotlib
- cvxopt: pip install cvxopt
- libpoly: Please follow the instruction at this URL (https://github.com/SRI-CSL/libpoly)
- gmp: brew install gmp 



3. Running the experiments described in the paper
---------------------------------------------------
The package includes three experiments. The files related to each experiment can be found in different subfolders (one for each experiment). To run any example, change the directory to one of the subfolders, and then run the python file inside. Details about each experiment and the expected results can be found below. 

All the experiments were executed using a MacBook Pro laptop with the following specifications:
- Processor: 2.6 GHz Intel Core i7
- Memory: 16 GB 2667 MHz DDR4
- Disk space: 500 GHz
- Operating System: macOS Catalina version 10.15.7
Different runs for the same test case can lead to slightly different execution times.

IFAC_Conference_Wael_Fatnassi.pdf is a copy of the paper.

 


4. Description of the Experiments
---------------------------------------------------
4.1) First experiment (Table 1 in the paper):
---------------------------------------------
The purpose of this experiment is to test the scalability of the following solvers on control synthesis problems:

1) Z3 8.9: A state-of-the-art SMT solver

2) Yices 2.6: A state-of-the-art SMT solver

3) PolyAR + Z3 (1 thread): Proposed in our paper. This version uses one instance of Z3 to analyze all the ambiguous regions. 
4) PolyAR + Z3 (max threads): Proposed in our paper. This version uses a sep- arate instance of Z3 to analyze each of the ambiguous regions. All Z3 instances are running in parallel. 
5) PolyAR + Yices (1 thread): Proposed in our paper. This version uses one instance of Yices to analyze all the ambiguous regions.    
6) PolyAR + Yices (max thread): Proposed in our paper. This version uses a separate instance of Yices to analyze each of the ambiguous regions. All Yices instances are running in parallel. 

The timeout period for the first experiment (Table 1 in the paper) is set to 3600 seconds.

We consider the following five instances of the controller synthesis problem:
4.1.1) Example 1:
-----------------

- Example 1 has 3 polynomial constraints with 16 variables and max polynomial order of 4. We restrict the elements of the controller matrix to be inside [−4, 7]. 

- To run each solver on Example 1, go to the folder Table1/solver_name/Example1 and run the following instruction:

Run > python3 Example1.py
Outputs:

- For Z3 8.9: timeout
- For Yices 2.6: timeout
- For PolyAR + Z3 (1 thread): timeout 
- For PolyAR + Z3 (max threads): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (1 thread): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (max thread): ‘SAT’ followed by execution time (in seconds)

4.1.2) Example 2:
-----------------

- Example 2 has 3 polynomial constraints with 25 variables and max polynomial order of 3. We restrict the elements of the controller matrix to be inside [−0.5, 1]. 

- To run each solver on Example 2, go to the folder Table1/solver_name/Example2 and run the following instruction:

Run > python3 Example2.py
Outputs:

- For Z3 8.9: timeout
- For Yices 2.6: timeout
- For PolyAR + Z3 (1 thread): ‘SAT’ followed by execution time (in seconds) 
- For PolyAR + Z3 (max threads): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (1 thread):    timeout
- For PolyAR + Yices (max thread): ‘SAT’ followed by execution time (in seconds)

4.1.3) Example 3:
-----------------

- Example 3 has 2 polynomial constraints with 36 variables and max polynomial order of 3. We restrict the elements of the controller matrix to be inside [0, 5]. 

- To run each solver on Example 3, go to the folder Table1/solver_name/Example3 and run the following instruction:

Run > python3 Example3.py
Outputs:

- For Z3 8.9: timeout
- For Yices 2.6: timeout
- For PolyAR + Z3 (1 thread): ‘SAT’ followed by execution time (in seconds) 
- For PolyAR + Z3 (max threads): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (1 thread):    timeout
- For PolyAR + Yices (max thread): ‘SAT’ followed by execution time (in seconds)

4.1.4) Example 4:
-----------------

- Example 4 has 2 polynomial constraints with 49 variables and max polynomial order of 2. We restrict the elements of the controller matrix to be inside [-10, 0]. 

- To run each solver on Example 4, go to the folder Table1/solver_name/Example4 and run the following instruction:

Run > python3 Example4.py
Outputs:

- For Z3 8.9: timeout
- For Yices 2.6: timeout
- For PolyAR + Z3 (1 thread): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Z3 (max threads): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (1 thread): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (max thread): ‘SAT’ followed by execution time (in seconds)


4.1.5) Example 5:
-----------------

- Example 5 has 5 polynomial constraints with 16 variables and max polynomial order of 4. We restrict the elements of the controller matrix to be inside [-4, 7]. 

- To run each solver on Example 5, go to the folder Table1/solver_name/Example4 and run the following instruction:

Run > python3 Example5.py
Outputs:

- For Z3 8.9: timeout
- For Yices 2.6: timeout
- For PolyAR + Z3 (1 thread): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Z3 (max threads): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (1 thread): ‘SAT’ followed by execution time (in seconds)
- For PolyAR + Yices (max thread): ‘SAT’ followed by execution time (in seconds)


4.2) Second experiment (Figure 4 in the paper):
--------------------------------------------------- 
- The purpose of this experiment is to test the scalability of the solvers described in subsection 4.1 on synthesizing a non-parametric controller for a Duffing oscillator reported by Fotiou et al. (2006).

- We consider the following three instances of the controller synthesis problem for the Duffing oscillator:

4.2.1) Instance 1:
-----------------
- Instance 1 has n=2 and results in 6 polynomial constraints with 3 variables and max polynomial order of 11.

- To obtain the 2 figures (State space and execution time evolution over time) for n=2, go to Figure4 folder and run the following instruction:

Run > python3 Duffing_Oscillator_n2.py
Outputs:
- Two figures for the State space and execution time evolution over time.


4.2.2) Instance 2:
-----------------
- Instance 2 has n=3 and results in 8 polynomial constraints with 4 variables and max polynomial order of 5.

- To obtain the 2 figures (State space and execution time evolution over time) for n=3, go to Figure4 folder and run the following instruction:

Run > python3 Duffing_Oscillator_n3.py
Outputs:
- Two figures for the State space and execution time evolution over time.

4.2.1) Instance 3:
-----------------
- Instance 3 has n=4 and results in 10 polynomial constraints with 5 variables and max polynomial order of 4.

- To obtain the 2 figures (State space and execution time evolution over time) for n=4, go to Figure4 folder and run the following instruction:

Run > python3 Duffing_Oscillator_n4.py
Outputs:
- Two figures for the State space and execution time evolution over time.


4.3) Third experiment (Figure 5 in the paper):
---------------------------------------------------
The purpose of this experiment is to to use the PolyAR solver to successfully design a controller for a continuous-time linear switching system. 


- To obtain Figure 5 in the paper, go to Figure5 folder and run the following instruction:

Run > python3 main.py
Outputs:
- Boolean solutions: [b11,b12,b13,b21,b22,b23,b31,b32,b33] = [True, False, False, False, True, False, False, False, True].
- Time solutions: [t1,t2,t3] = [Fraction(401, 1024), Fraction(1, 2), Fraction(1, 4)].
- Figure 5.

Note: The execution of this experiment takes up to 19 minutes.




 
