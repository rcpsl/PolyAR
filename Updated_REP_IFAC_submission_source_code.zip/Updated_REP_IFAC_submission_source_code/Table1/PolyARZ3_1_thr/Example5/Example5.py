from sympy import *
import sympy
import PolyARBOOL
import numpy as np
import polytope as pc
import time
import ast
import z3



# ========================================================
#   Function to output the n^th dimenstion hypercube
#      with edge limited between xmin and xmax
# ========================================================
def hypercube(n,xmin,xmax):
    box=[]
    for i in range(n):
        box.append([xmin,xmax])
    
    return box  



# ========================================================
#   Function to output the string s in the poly structure
#                    for our algorithm
# ========================================================
def polyconstr(s):
    varlist= sympy.symbols('K1_1,K1_2,K1_3,K1_4,K2_1,K2_2,K2_3,K2_4,K3_1,K3_2,K3_3,K3_4,K4_1,K4_2,K4_3,K4_4') 
    
    numden=fraction(together(s))
    s= numden[0]* numden[1]    
    
    polycs=[]
    term={}
    poly=sympy.poly(s,varlist)

    polypowers=poly.monoms()
    polycoeffs=poly.coeffs()
    
    for j in range(len(polycoeffs)):
        varspows=[]
        for k in range(len(polypowers[j])):
            varspows.append({'power':polypowers[j][k]})
            
        term={'coeff':float(polycoeffs[j]),'vars':varspows}
        polycs.append(term)   
            

    return polycs



#----------------List to contain all the constraints in dictionary form for our alg------
Constraints=[]





# open file and read the content in a list
with open('Polysfile.txt', 'r') as filehandle:
    filecontents = filehandle.readlines()

    for line in filecontents:
        # remove linebreak which is the last character of the string
        current_place = line[:-1]

        # add item to the list
        Constraints.append(current_place)






#------------------- SMP Solver -------------------------



numberOfBoolVars=2
numOfRealVars=16    
numOfPolyIFClauses=5


x_min=-4.0
x_max =7.0




box=np.array(hypercube(numOfRealVars, x_min,x_max))
polype=pc.box2poly(box)
pregion=[[{'A':polype.A,'b':polype.b}]]




solver                  = PolyARBOOL.SMPolyIneqSolver(numberOfBoolVars, numOfRealVars, numOfPolyIFClauses, pregion,
                        maxNumberOfIterations=10000,
                        counterExampleStrategy='Trivial',
                        verbose='ON',
                        profiling='false')

#---- Declare Stability Constraints ----

for i in range(len(Constraints)):
    solver.addPolyConstraint(ast.literal_eval(Constraints[i])) 

solver.addPolyConstraint(polyconstr('-K2_1*K2_2*K2_3'))


solver.addPolyConstraint(polyconstr('-1-K2_1-K2_2-K2_3'))



for i in range(len(solver.poly_inequality_coeffs)):

    poly=solver.poly_inequality_coeffs[i]
    for monomial_counter in range(0,len(poly)):
        poly[monomial_counter]['coeff'] = -poly[monomial_counter]['coeff'] 
    


boolclause=z3.And(solver.bVars[0],solver.bVars[1])
solver.addBoolConstraint(boolclause)

solver.addBoolConstraint(solver.polyIFClauses[0])
solver.addBoolConstraint(solver.polyIFClauses[1])
solver.addBoolConstraint(solver.polyIFClauses[2])
solver.addBoolConstraint(z3.Implies(solver.bVars[0],solver.polyIFClauses[3]))
solver.addBoolConstraint(z3.Implies(solver.bVars[1],solver.polyIFClauses[4]))


#---- RUN THE SOLVER ---------------------------------

start_time = time.time()
res=solver.solve() 
elapsed_time= time.time() - start_time
print(res,elapsed_time)
