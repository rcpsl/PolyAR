from sympy import *
import sympy
import PolyAR
import numpy as np
import polytope as pc
import time
import ast

# ========================================================
#   Function to output the n^th dimenstion hypercube
#      with edge limited between xmin and xmax
# ========================================================
def hypercube(n,xmin,xmax):
    box=[]
    for i in range(n):
        box.append([xmin,xmax])
    
    return box  





#----------------List to contain all the constraints in dictionary form for our alg------
Constraints=[]

#----------------List to contain all the constraints in Yices form------------
fmlas=[]




# open file and read the content in a list
with open('Polysfile.txt', 'r') as filehandle:
    filecontents = filehandle.readlines()

    for line in filecontents:
        # remove linebreak which is the last character of the string
        current_place = line[:-1]

        # add item to the list
        Constraints.append(current_place)








#------------------- SMP Solver -------------------------
num_vars=16

x_min=-4.0
x_max =7.0


box=np.array(hypercube(num_vars, x_min,x_max))
polype=pc.box2poly(box)
boxx=pc.bounding_box(polype)
pregion=[[{'A':polype.A,'b':polype.b}]]
solver = PolyAR.PolyInequalitySolver(num_vars, pregion)

#---- Declare Stability Constraints ----

for i in range(len(Constraints)):
    solver.addPolyInequalityConstraint(ast.literal_eval(Constraints[i]))


for i in range(len(solver.poly_inequality_coeffs)):

    poly=solver.poly_inequality_coeffs[i]
    for monomial_counter in range(0,len(poly)):
        poly[monomial_counter]['coeff'] = -poly[monomial_counter]['coeff']  





    






#---- RUN THE SOLVER ----
poly_list=solver.poly_inequality_coeffs 
start_time = time.time()
res=solver.Yicesmany_multivars(poly_list, boxx)
elapsed_time= time.time() - start_time
print(res,elapsed_time)


