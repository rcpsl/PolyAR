#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 16:16:50 2020

@author: waelfatnassi
"""


import sympy
import PolyARn4
import numpy as np
import polytope as pc
import time
from scipy.integrate import solve_ivp, odeint
import matplotlib.pyplot as plt
from scipy.linalg import solve_discrete_lyapunov, solve_discrete_are



# h=0.05
# zeta=1.75
# epsilon=0.000000000001


# x10=0.1
# x20=0.1
# x30=0.01
# x40=0.1

# k1=1
# k2=1.8
# k3=6
# k4=1


# state1=[x10]
# state2=[x20]
# state3=[x30]
# state4=[x40]
# tim=[]
# uvec=[]


# # ========================================================
# #   Evaluate the multivar poly at point x
# # ========================================================

# def evaluate_multivar_poly(poly, x):
#     result = 0
#     for monomial_counter in range(0,len(poly)):
#         coeff = poly[monomial_counter]['coeff']
#         vars  = poly[monomial_counter]['vars']
#         product = coeff
#         for var_counter in range(len(vars)):
#             power = vars[var_counter]['power']
#             var   = x[var_counter]  
#             product = product * (var**power)
#         result = result + product
#     return result





# t = np.linspace(0, 20, 400)


# for ii in range(1,400):
    
#     print(ii)

#     varlist= sympy.symbols('x1,x2,x3,x4,u0')
    
    
#     x1=sympy.poly('x1',varlist)
#     x2=sympy.poly('x2',varlist) 
#     x3=sympy.poly('x3',varlist)
#     x4=sympy.poly('x4',varlist)
    
#     u0=sympy.poly('u0',varlist)
    

    
    
#     x1pol=x10+h*x20
#     x2pol=x20+h*x30
#     x3pol=x30+h*x40
#     x4pol=(1-h)*x40-h*x30-2*zeta*h*x20-h*x10-h*x10**3+h*u0
    
    
    
    
#     const1=x1-x1pol-epsilon
#     const2=-x1+x1pol-epsilon
#     const3=x2-x2pol-epsilon
#     const4=-x2+x2pol-epsilon
#     const5=x3-x3pol-epsilon
#     const6=-x3+x3pol-epsilon
#     const7=x4-x4pol-epsilon
#     const8=-x4+x4pol-epsilon
    
#     const9=x4**4+x3**4+x2**4+x1**4-u0**4
    
    
#     # const9=u0-(-k1*x1-k2*x2-k3*x3-k4*x4)-epsilon
#     # const10=-u0+(-k1*x1-k2*x2-k3*x3-k4*x4)-epsilon
    
#     # const9=u0-(-1/3)*((1-h)*x40-h*x30-2*zeta*h*x20-h*x10-h*x10**3)-epsilon
#     # const10=-u0+(-1/3)*((1-h)*x40-h*x30-2*zeta*h*x20-h*x10-h*x10**3)-epsilon
    
#     # const7=x3**5+x2**5+x1**5+u0**5
    
#     # B=np.array([0, 0, 0, h])
#     # const9=u0-(0.1*(-B.dot(P)).dot(x))-epsilon
#     # const10=-u0+(0.1*(-B.dot(P)).dot(x))-epsilon
    
    
#     P=solve_discrete_lyapunov(np.array([[1, h, 0, 0],[0, 1, h, 0],[0, 0, 1, h],[-h-h*k1, -2*zeta*h-h*k2,-h-h*k3, 1-h-h*k4]]).T, np.array([[1, 0, 0, 0],[0, 1, 0, 0],[0, 0, 1, 0],[0, 0, 0, 1]]))
    
#     # A=np.array([[1, h, 0, 0],[0, 1, h, 0],[0, 0, 1, h], [-h, -2*zeta*h, -h, 1-h]])
#     # B=np.array([[0], [0], [0], [h]])
#     # Q=2*np.array([[1, 0, 0, 0],[0, 1, 0, 0],[0, 0, 1, 0],[0, 0, 0, 1]])
#     # R=2
#     # P=solve_discrete_are(A,B,Q,R)
    
#     # P=10*np.array([[1, 0, 0, 0],[0, 1, 0, 0],[0, 0, 1, 0],[0, 0, 0, 1]])
    
#     x0=np.array([x10,x20,x30,x40])
#     x=np.array([x1,x2,x3,x4])
#     constV=((x.dot(P)).dot(x)-(x0.dot(P)).dot(x0))+0.0000000000001   
    
    

    
    
    
    
#     cons=[const1,const2,const3,const4,const5,const6,const7,const8,const9,constV]
    
    
#     poly_list=[]
#     for i in range(len(cons)):
#         polycs=[]
#         term={}
#         poly=cons[i]
#         polypowers=poly.monoms()
#         polycoeffs=poly.coeffs()


#         for j in range(len(polycoeffs)):
#             varspows=[]
#             for k in range(len(polypowers[j])):
#                 varspows.append({'power':polypowers[j][k]})
                
#             term={'coeff':float(polycoeffs[j]),'vars':varspows}
#             polycs.append(term)   
            
#         poly_list.append(polycs) 
        
        
#     ################################################## Solvers #########################################
        
        
#     # ========================================================
#     #   Duffing Function
#     # ========================================================       
#     def Duffing_fun(x, t, u):      
#         # dxdt=[x[1],u-2*zeta*x[1]-x[0]-x[0]**3]
#         ddxdt=[x[1],x[2],x[3],u-x[3]-x[2]-2*zeta*x[1]-x[0]-x[0]**3]
#         return ddxdt 
    
#     # ========================================================
#     #   Function to output the n^th dimenstion hypercube
#     #      with edge limited between xmin and xmax
#     # ========================================================
#     def hypercube(n,xmin,xmax):
#         box=[]
#         for i in range(n):
#             box.append([xmin,xmax])
        
#         return box      
    
    
#     num_vars=5
    
#     x_min=-0.6
#     x_max =0.6
    
    
#     box=np.array(hypercube(num_vars, x_min,x_max))
#     polype=pc.box2poly(box)
#     pregion=[[{'A':polype.A,'b':polype.b}]]
#     boxx=pc.bounding_box(polype)
#     solver = PolyARn4.PolyInequalitySolver(num_vars, pregion)
    
    
#     solver.poly_inequality_coeffs =poly_list
    
#     # if ii==27:
    
#     #     break
#     ####################################################Running Solvers ##################################
#     ##################################### Our solver #############################
    
#     start_time = time.time()
#     status,res=solver.solve()
#     # status,res=solver.solveYices(poly_list,boxx)
#     # status,res=solver.solveZ3(poly_list,boxx)
#     elapsed_time= time.time() - start_time
#     print(status,'   ', res,'    ', elapsed_time)
    
        


#     ttt = np.linspace(t[ii-1], t[ii], 1000)
#     x = odeint(Duffing_fun,[x10, x20, x30, x40], ttt, args=(res,))
    


#     print(x[-1][0],'   ',x[-1][1],'  ',x[-1][2])
#     state1.append(x[-1][0])
#     state2.append(x[-1][1])
#     # state3.append(x[-1][2])
#     tim.append(elapsed_time)
#     uvec.append(res)
    

#     x10=x[-1][0]
#     x20=x[-1][1]  
#     x30=x[-1][2] 
#     x40=x[-1][3]
    
#     if (elapsed_time > 1):
#         break
    
# #     print('###########################################################################################')

    
    

# # tim.append(10)    


# state1=np.array(state1)
# state2=np.array(state2)
# tim=np.array(tim)
# # uvec=np.array(uvec)

# np.save('state1polyaryn4.npy',state1)
# np.save('state2polyaryn4.npy',state2)
# np.save('timpolyaryn4.npy',tim)


# plt.plot(t, state1, "b-", t, state2, "r--")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$x_1(t), x_2(t)$')
# plt.legend([r'$x_1(t)$',r'$x_2(t)$'])
# plt.show()


# plt.plot(t[:-1], uvec, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$u(t)$')
# plt.show()


# plt.plot(state1, state2, "b-")
# plt.xlabel(r'$x_1(t)$')
# plt.ylabel(r'$x_2(t)$')
# plt.xlim([-0.1,0.1])
# plt.ylim([-0.1,0.1])
# plt.show()

# plt.plot(t[:-1], tim, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'Evolution Time (seconds)')
# # plt.legend([r'$N=3$',r'$N=4$',r'$N=5$'])
# plt.ylim([0,1])
# plt.show()






















state1polyaryn4=np.load('state1polyaryn4.npy')
state2polyaryn4=np.load('state2polyaryn4.npy')


state1polyarzn4=np.load('state1polyarzn4.npy')
state2polyarzn4=np.load('state2polyarzn4.npy')

state1yicesn4=np.load('state1yicesn4.npy')
state2yicesn4=np.load('state2yicesn4.npy')

state1z3n4=np.load('state1z3n4.npy')
state2z3n4=np.load('state2z3n4.npy')


timpolyaryn4=np.load('timpolyaryn4.npy')

timpolyarzn4=np.load('timpolyarzn4.npy')

timyicesn4=np.load('timyicesn4.npy')

timz3n4=np.load('timz3n4.npy')




t = np.linspace(0, 20, 400)

plt.plot(state1polyaryn4, state2polyaryn4, "b-",state1polyarzn4, state2polyarzn4, "r", state1yicesn4, state2yicesn4, "k", state1z3n4, state2z3n4, "g")
plt.xlabel(r'$x_1(t)$')
plt.ylabel(r'$x_2(t)$')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$',r'$Z3$'])
plt.xlim([-0.15,0.25])
plt.ylim([-0.15,0.15])
plt.show()

plt.plot(t[:len(timpolyaryn4)], timpolyaryn4, "b-", t[:len(timpolyarzn4)], timpolyarzn4, "r-", t[:len(timyicesn4)], timyicesn4, "k-", t[:len(timz3n4)], timz3n4, "g-")
plt.xlabel(r'$t$')
plt.ylabel(r'Evolution Time (seconds)')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$',r'$Z3$'])
plt.ylim([0,1])
plt.show()








