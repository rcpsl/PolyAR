#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 16:16:50 2020

@author: waelfatnassi
"""


import sympy
import PolyARn2
import numpy as np
import polytope as pc
import time
from scipy.integrate import solve_ivp, odeint
import matplotlib.pyplot as plt
from scipy.linalg import solve_discrete_lyapunov



# h=0.05
# zeta=0.3
# epsilon=0.000000000001


# x10=0.4
# x20=-0.1


# state1=[x10]
# state2=[x20]
# tim=[]
# uvec=[]

# sumt=0
# # ========================================================
# #   Evaluate the multivar poly at point x
# # ========================================================

# def evaluate_multivar_poly(poly, x):
#     result = 0
#     for monomial_counter in range(0,len(poly)):
#         coeff = poly[monomial_counter]['coeff']
#         vars  = poly[monomial_counter]['vars']
#         product = coeff
#         for var_counter in range(len(vars)):
#             power = vars[var_counter]['power']
#             var   = x[var_counter]  
#             product = product * (var**power)
#         result = result + product
#     return result





# t = np.linspace(0, 20, 400)


# for ii in range(1,400):
#     print(ii)


#     varlist= sympy.symbols('x1,x2,u0')
    
    
#     x1=sympy.poly('x1',varlist)
#     x2=sympy.poly('x2',varlist)    
    
#     u0=sympy.poly('u0',varlist)
    

    
    
#     x1pol=x10+h*x20
#     x2pol=-h*x10+(1-2*zeta*h)*x20+h*u0-h*x10**3
    
    
    
    
#     const1=x1-x1pol-epsilon
#     const2=-x1+x1pol-epsilon
#     const3=x2-x2pol-epsilon
#     const4=-x2+x2pol-epsilon
    
#     const5=x1**11+x2**11-u0**10
    
#     P=solve_discrete_lyapunov(np.array([[1, h],[-h, 1-2*zeta*h]]).T, np.array([[1, 0],[0, 1]]))
    
        
#     # constV=42.63653658*x1**2+36.64034127*x2**2+2*10.91600853*x1*x2-(42.63653658*x10**2+36.64034127*x20**2+2*10.91600853*x10*x20)-0.0000000000001
 
    
#     x0=np.array([x10,x20])
#     x=np.array([x1,x2])
#     constV=(x.dot(P)).dot(x)-(x0.dot(P)).dot(x0)+0.0000000000001  
    
    
#     cons=[const1,const2,const3,const4,const5,constV]
    
    
#     poly_list=[]
#     for i in range(len(cons)):
#         polycs=[]
#         term={}
#         poly=cons[i]
#         polypowers=poly.monoms()
#         polycoeffs=poly.coeffs()


#         for j in range(len(polycoeffs)):
#             varspows=[]
#             for k in range(len(polypowers[j])):
#                 varspows.append({'power':polypowers[j][k]})
                
#             term={'coeff':float(polycoeffs[j]),'vars':varspows}
#             polycs.append(term)   
            
#         poly_list.append(polycs) 
        
        
#     ################################################## Solvers #########################################
        
        
#     # ========================================================
#     #   Duffing Function
#     # ========================================================       
#     def Duffing_fun(x, t, u):      
#         dxdt=[x[1],u-2*zeta*x[1]-x[0]-x[0]**3]
#         return dxdt 
    
#     # ========================================================
#     #   Function to output the n^th dimenstion hypercube
#     #      with edge limited between xmin and xmax
#     # ========================================================
#     def hypercube(n,xmin,xmax):
#         box=[]
#         for i in range(n):
#             box.append([xmin,xmax])
        
#         return box      
    
    
#     num_vars=3
    
#     x_min=-0.6
#     x_max =0.6
    
    
#     box=np.array(hypercube(num_vars, x_min,x_max))
#     polype=pc.box2poly(box)
#     pregion=[[{'A':polype.A,'b':polype.b}]]
#     boxx=pc.bounding_box(polype)
#     solver = PolyARn2.PolyInequalitySolver(num_vars, pregion)
    
    
#     solver.poly_inequality_coeffs =poly_list
    
    
#     ####################################################Running Solvers ##################################
#     ##################################### Our solver #############################
    
#     start_time = time.time()
#     status,res=solver.solve()
#     # status,res=solver.solveYices(poly_list,boxx)
#     # status,res=solver.solveZ3(poly_list,boxx)
#     elapsed_time= time.time() - start_time
#     print(status,'   ', res,'    ', elapsed_time)
    
#     sumt=sumt+elapsed_time


#     ttt = np.linspace(t[ii-1], t[ii], 1000)
#     x = odeint(Duffing_fun,[x10, x20], ttt, args=(res,))
    


#     print(x[-1][0],'   ',x[-1][1])
#     state1.append(x[-1][0])
#     state2.append(x[-1][1])
#     tim.append(elapsed_time)
#     uvec.append(res)
    

#     x10=x[-1][0]
#     x20=x[-1][1] 
    
#     if (elapsed_time > 1):
#         break
    
#     print('###########################################################################################')

    
    

    
# print('sumt=',sumt)

# state1=np.array(state1)
# state2=np.array(state2)
# tim=np.array(tim)
# # uvec=np.array(uvec)

# np.save('state1polyaryn2.npy',state1)
# np.save('state2polyaryn2.npy',state2)
# np.save('timpolyaryn2.npy',tim)


# plt.plot(t, state1, "b-", t, state2, "r--", t, state3, "k--")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$x_1(t), x_2(t), x_3(t)$')
# plt.legend([r'$x_1(t)$',r'$x_2(t)$',r'$x_3(t)$'])
# plt.show()


# plt.plot(t[:-1], uvec, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$u(t)$')
# plt.show()


# plt.plot(state1, state2, "b-")
# plt.xlabel(r'$x_1(t)$')
# plt.ylabel(r'$x_2(t)$')
# plt.xlim([-0.6,0.6])
# plt.ylim([-0.6,0.6])
# plt.show()

# plt.plot(t[:-1], tim, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'Evolution Time (seconds)')
# # plt.legend([r'$N=3$',r'$N=4$',r'$N=5$'])
# plt.ylim([0,0.1])
# plt.show()









state1polyaryn2=np.load('state1polyaryn2.npy')
state2polyaryn2=np.load('state2polyaryn2.npy')


state1polyarzn2=np.load('state1polyarzn2.npy')
state2polyarzn2=np.load('state2polyarzn2.npy')

state1yicesn2=np.load('state1yicesn2.npy')
state2yicesn2=np.load('state2yicesn2.npy')




timpolyaryn2=np.load('timpolyaryn2.npy')

timpolyarzn2=np.load('timpolyarzn2.npy')

timyicesn2=np.load('timyicesn2.npy')






t = np.linspace(0, 20, 400)

plt.plot(state1polyaryn2, state2polyaryn2, "b-",state1polyarzn2, state2polyarzn2, "r", state1yicesn2, state2yicesn2, "k")
plt.xlabel(r'$x_1(t)$')
plt.ylabel(r'$x_2(t)$')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$'])
plt.xlim([-0.6,0.6])
plt.ylim([-0.6,0.6])
plt.show()

plt.plot(t[:len(timpolyaryn2)], timpolyaryn2, "b-", t[:len(timpolyarzn2)], timpolyarzn2, "r-", t[:len(timyicesn2)], timyicesn2, "k-")
plt.xlabel(r'$t$')
plt.ylabel(r'Evolution Time (seconds)')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$'])
plt.ylim([0,1])
plt.show()










