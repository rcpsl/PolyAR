#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 24 16:16:50 2020

@author: waelfatnassi
"""


import sympy
import PolyARn3
import numpy as np
import polytope as pc
import time
from scipy.integrate import solve_ivp, odeint
import matplotlib.pyplot as plt
from scipy.linalg import solve_discrete_lyapunov



# h=0.05
# zeta=1.0
# epsilon=0.000000000001


# x10=0.1
# x20=0.1
# x30=0.1


# state1=[x10]
# state2=[x20]
# state3=[x30]
# tim=[]
# uvec=[]


# # ========================================================
# #   Evaluate the multivar poly at point x
# # ========================================================

# def evaluate_multivar_poly(poly, x):
#     result = 0
#     for monomial_counter in range(0,len(poly)):
#         coeff = poly[monomial_counter]['coeff']
#         vars  = poly[monomial_counter]['vars']
#         product = coeff
#         for var_counter in range(len(vars)):
#             power = vars[var_counter]['power']
#             var   = x[var_counter]  
#             product = product * (var**power)
#         result = result + product
#     return result





# t = np.linspace(0, 20, 400)


# for ii in range(1,400):


#     varlist= sympy.symbols('x1,x2,x3,u0')
    
    
#     x1=sympy.poly('x1',varlist)
#     x2=sympy.poly('x2',varlist) 
#     x3=sympy.poly('x3',varlist)
    
#     u0=sympy.poly('u0',varlist)
    

    
    
#     x1pol=x10+h*x20
#     x2pol=x20+h*x30
#     x3pol=(1-h)*x30-2*zeta*h*x20-h*x10-h*x10**3+h*u0
    
    
    
    
#     const1=x1-x1pol-epsilon
#     const2=-x1+x1pol-epsilon
#     const3=x2-x2pol-epsilon
#     const4=-x2+x2pol-epsilon
#     const5=x3-x3pol-epsilon
#     const6=-x3+x3pol-epsilon
    
#     const7=x3**5+x2**5+x1**5+u0**5
    
    
#     P=solve_discrete_lyapunov(np.array([[1, h, 0],[0, 1, h], [-h, -2*zeta*h, 1-h]]).T, np.array([[1, 0, 0],[0, 1, 0],[0, 0, 1]]))
    
#     x0=np.array([x10,x20,x30])
#     x=np.array([x1,x2,x3])
#     constV=(x.dot(P)).dot(x)-(x0.dot(P)).dot(x0)+0.0000000000001    
    
    
#     cons=[const1,const2,const3,const4,const5,const6,const7,constV]
    
    
#     poly_list=[]
#     for i in range(len(cons)):
#         polycs=[]
#         term={}
#         poly=cons[i]
#         polypowers=poly.monoms()
#         polycoeffs=poly.coeffs()


#         for j in range(len(polycoeffs)):
#             varspows=[]
#             for k in range(len(polypowers[j])):
#                 varspows.append({'power':polypowers[j][k]})
                
#             term={'coeff':float(polycoeffs[j]),'vars':varspows}
#             polycs.append(term)   
            
#         poly_list.append(polycs) 
        
        
#     ################################################## Solvers #########################################
        
        
#     # ========================================================
#     #   Duffing Function
#     # ========================================================       
#     def Duffing_fun(x, t, u):      
#         # dxdt=[x[1],u-2*zeta*x[1]-x[0]-x[0]**3]
#         ddxdt=[x[1],x[2],u-x[2]-2*zeta*x[1]-x[0]-x[0]**3]
#         return ddxdt 
    
#     # ========================================================
#     #   Function to output the n^th dimenstion hypercube
#     #      with edge limited between xmin and xmax
#     # ========================================================
#     def hypercube(n,xmin,xmax):
#         box=[]
#         for i in range(n):
#             box.append([xmin,xmax])
        
#         return box      
    
    
#     num_vars=4
    
#     x_min=-0.6
#     x_max =0.6
    
    
#     box=np.array(hypercube(num_vars, x_min,x_max))
#     polype=pc.box2poly(box)
#     pregion=[[{'A':polype.A,'b':polype.b}]]
#     boxx=pc.bounding_box(polype)
#     solver = PolyARn3.PolyInequalitySolver(num_vars, pregion)
    
    
#     solver.poly_inequality_coeffs =poly_list
    
    
#     ####################################################Running Solvers ##################################
#     ##################################### Our solver #############################
    
#     start_time = time.time()
#     status,res=solver.solve()
#     # status,res=solver.solveYices(poly_list,boxx)
#     # status,res=solver.solveZ3(poly_list,boxx)
#     elapsed_time= time.time() - start_time
#     print(status,'   ', res,'    ', elapsed_time)
    
        


#     ttt = np.linspace(t[ii-1], t[ii], 1000)
#     x = odeint(Duffing_fun,[x10, x20, x30], ttt, args=(res,))
    


#     print(x[-1][0],'   ',x[-1][1],'  ',x[-1][2])
#     state1.append(x[-1][0])
#     state2.append(x[-1][1])
#     state3.append(x[-1][2])
#     tim.append(elapsed_time)
#     uvec.append(res)
    

#     x10=x[-1][0]
#     x20=x[-1][1]  
#     x30=x[-1][2] 
    
#     if (elapsed_time > 1):
#         break
    
#     print('###########################################################################################')

    
    

    


# state1=np.array(state1)
# state2=np.array(state2)
# state3=np.array(state3)
# tim=np.array(tim)
# uvec=np.array(uvec)

# np.save('state1polyaryn3.npy',state1)
# np.save('state2polyaryn3.npy',state2)
# np.save('timpolyaryn3.npy',tim)


# plt.plot(t, state1, "b-", t, state2, "r--", t, state3, "k--")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$x_1(t), x_2(t), x_3(t)$')
# plt.legend([r'$x_1(t)$',r'$x_2(t)$',r'$x_3(t)$'])
# plt.show()


# plt.plot(t[:-1], uvec, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'$u(t)$')
# plt.show()


# plt.plot(state1, state2, "b-")
# plt.xlabel(r'$x_1(t)$')
# plt.ylabel(r'$x_2(t)$')
# plt.xlim([-0.6,0.6])
# plt.ylim([-0.6,0.6])
# plt.show()

# plt.plot(t[:-1], tim, "b-")
# plt.xlabel(r'$t$')
# plt.ylabel(r'Evolution Time (seconds)')
# # plt.legend([r'$N=3$',r'$N=4$',r'$N=5$'])
# plt.ylim([0,0.1])
# plt.show()









state1polyaryn3=np.load('state1polyaryn3.npy')
state2polyaryn3=np.load('state2polyaryn3.npy')


state1polyarzn3=np.load('state1polyarzn3.npy')
state2polyarzn3=np.load('state2polyarzn3.npy')

state1yicesn3=np.load('state1yicesn3.npy')
state2yicesn3=np.load('state2yicesn3.npy')

state1z3n3=np.load('state1z3n3.npy')
state2z3n3=np.load('state2z3n3.npy')


timpolyaryn3=np.load('timpolyaryn3.npy')

timpolyarzn3=np.load('timpolyarzn3.npy')

timyicesn3=np.load('timyicesn3.npy')

timz3n3=np.load('timz3n3.npy')




t = np.linspace(0, 20, 400)

plt.plot(state1polyaryn3, state2polyaryn3, "b-",state1polyarzn3, state2polyarzn3, "r", state1yicesn3, state2yicesn3, "k", state1z3n3, state2z3n3, "g")
plt.xlabel(r'$x_1(t)$')
plt.ylabel(r'$x_2(t)$')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$',r'$Z3$'])
plt.xlim([-0.15,0.2])
plt.ylim([-0.15,0.15])
plt.show()

plt.plot(t[:len(timpolyaryn3)], timpolyaryn3, "b-", t[:len(timpolyarzn3)], timpolyarzn3, "r-", t[:len(timyicesn3)], timyicesn3, "k-", t[:len(timz3n3)], timz3n3, "g-")
plt.xlabel(r'$t$')
plt.ylabel(r'Evolution Time (seconds)')
plt.legend([r'$PolyAR+Yices$',r'$PolyAR+Z3$',r'$Yices$',r'$Z3$'])
plt.ylim([0,1])
plt.show()








